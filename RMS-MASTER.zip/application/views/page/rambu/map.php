<div class="col-lg-8">	
	<div class="card">
        <div class="card-body">
        	<div class="row">
  				  <iframe class="col-lg-12" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d253202.93956776496!2d111.25440001520727!3d-7.4324689255767336!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e79e8bb536eb601%3A0x3027a76e352be90!2sNgawi%20Regency%2C%20East%20Java!5e0!3m2!1sen!2sid!4v1621756155128!5m2!1sen!2sid" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
  			  </div>             
        </div>
    </div>
</div>

<!-- [START maps_map_simple] -->
<script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
<link rel="stylesheet" type="text/css" href="./style.css" />
<script src="./index.js"></script>
<div id="map"></div>

<!-- Async script executes immediately and must be after any DOM elements used in callback. -->
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&callback=initMap&libraries=&v=weekly"
  async ></script>
